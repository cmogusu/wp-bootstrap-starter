<?php
namespace post_menu;

class post_inner_menu{
	protected $post_meta_key = 'post_inner_menu';
}