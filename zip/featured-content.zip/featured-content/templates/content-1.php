<div class="featured-content featured-content-1">
	Featured content 1
</div>