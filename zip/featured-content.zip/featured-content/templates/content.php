<div class="featured-content">
	Featured content
</div>