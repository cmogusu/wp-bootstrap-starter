<div class="featured-content featured-content-3">
	Featured content 3
</div>