<div class="featured-content featured-content-2">
	Featured Content 2
</div>